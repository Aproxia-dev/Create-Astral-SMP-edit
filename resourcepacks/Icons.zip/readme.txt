----------------[Terms of use]---------------------

If you use anything out of this pack that includes the NegativeSpaces4 resource pack under Creative Commons Attribution 4.0 International terms, you need to credit AmberW/AmberWat.

Using anything aside from the NegativeSpaces4 pack, you need to ask us for permissions.
This includes the icons themselves and the Unicode system for only the icons.
No one is allowed to redistribute Icons as is without written permission.

 

You can:
Use it as a template to understand and make something your own
Create an addon for it
Change/add to the pack to the point they are distinguishable on their own.

 

For people wanting to use the pack on a server or in modpacks:

As long as you don't remove the "credits.txt" and "readme.txt", you don't need to specify who made the pack anywhere else. Given, that if you leave the "WeNAN Studios" texture in the escape menu, that would already credit us but keeping it isn't necessary if you're editing the pack. Using the entire pack, you need to credit AmberW of course.

You don't need to ask for permission if the server is just a small one with a group of friends.

You also don't have to ask us if one or both terms apply. You can of course inform us when using Icons but you don't have to.

----------------[Credit]---------------------------


--Pack Creators:--

mr_ch0c0late (Creator and Idea)

Curse Forge: 		https://www.curseforge.com/members/mr_ch0c0late1
Planet Minecraft: 	https://www.planetminecraft.com/member/mr_ch0c0late1/
Twitter: 			https://twitter.com/mr_ch0c0late1



Zartrix 

Curse Forge:		https://www.curseforge.com/members/zartrix
Reddit: 			https://www.reddit.com/user/Zartrix



AmberW/AmberWat

GitHub:			https://github.com/AmberWat
Discord(Minecraft Commands)